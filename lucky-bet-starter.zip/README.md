# Lucky Bet Starter

Gaming-style multilingual starter project.
