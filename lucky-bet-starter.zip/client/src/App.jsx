export default function App() {
  return (
    <div style={{padding:'40px',fontFamily:'sans-serif'}}>
      <h1>Lucky Bet Gaming Portal</h1>
      <p>Frontend starter is working.</p>

      <h2>Deposit Information</h2>
      <ul>
        <li>bKash: +8801918701851</li>
        <li>Nagad: +8801784952994</li>
      </ul>

      <a href="/admin">Open Admin Panel</a>
    </div>
  )
}
