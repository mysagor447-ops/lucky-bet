const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'Lucky Bet backend running' });
});

app.get('/api/deposit', (req, res) => {
  res.json({
    bkash: '+8801918701851',
    nagad: '+8801784952994'
  });
});

app.listen(5000, () => {
  console.log('Server running on port 5000');
});
